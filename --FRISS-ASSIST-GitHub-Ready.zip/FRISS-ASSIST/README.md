# FRISS ASSIST

Asisten Android native berbasis Kotlin dengan floating overlay.

## Fitur
- Floating logo "F" yang bisa digeser di atas aplikasi lain.
- Pengaturan opacity logo.
- Slider kecerahan layar Android.
- Panel kontrol mengambang.
- Tombol akses Google Lens (bergantung pada ketersediaan aplikasi Google/Lens di perangkat).
- Tanpa akun dan tanpa database eksternal.

## Build APK lewat GitHub
1. Buat repository GitHub baru, misalnya `friss-assist`.
2. Upload seluruh isi folder project ini ke root repository.
3. Buka tab **Actions**.
4. Pilih workflow **Build FRISS ASSIST APK**.
5. Tekan **Run workflow** (atau push ke branch `main`).
6. Setelah selesai, buka hasil workflow dan unduh artifact `FRISS-ASSIST-debug`.
7. Ekstrak artifact untuk mendapatkan `app-debug.apk`.

## Build lokal
Memerlukan JDK 17 dan Gradle 8.9+.
```bash
gradle assembleDebug
```
APK berada di `app/build/outputs/apk/debug/app-debug.apk`.

## Izin Android
- **Tampil di atas aplikasi lain** dibutuhkan untuk floating logo/panel.
- **Ubah setelan sistem** dibutuhkan untuk mengubah kecerahan sistem.
Pengguna mengaktifkan izin sendiri dari halaman pengaturan Android yang dibuka aplikasi.

## Catatan kompatibilitas
- Ditargetkan untuk Android 6.0+ (minSdk 23), compile/target SDK 35.
- Google Lens bukan API publik yang stabil untuk dipanggil aplikasi pihak ketiga. Tombol mencoba membuka Lens melalui intent Google; jika intent tidak tersedia, aplikasi membuka Google atau halaman Lens sebagai fallback.
- HyperOS dapat membatasi aplikasi latar belakang. Jika overlay berhenti setelah beberapa saat, izinkan FRISS ASSIST berjalan otomatis/tanpa batasan baterai melalui pengaturan sistem Xiaomi.
- Kontrol kecerahan mengubah nilai brightness sistem; Android dapat menerapkan perilaku berbeda pada mode kecerahan otomatis.
