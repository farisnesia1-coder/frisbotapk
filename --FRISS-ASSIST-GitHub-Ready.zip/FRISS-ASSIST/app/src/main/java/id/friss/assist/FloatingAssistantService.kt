package id.friss.assist

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class FloatingAssistantService : Service() {
    private lateinit var windowManager: WindowManager
    private var bubble: TextView? = null
    private var panel: LinearLayout? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private var opacity = 85
    private val blue = 0xFF1677FF.toInt()
    private val dark = 0xFF10233D.toInt()

    override fun onCreate() {
        super.onCreate()
        createNotification()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        if (Settings.canDrawOverlays(this)) showBubble()
        else stopSelf()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    private fun createNotification() {
        val channelId = "friss_assist_running"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, "FRISS ASSIST", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val notification = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, channelId)
        } else Notification.Builder(this)
        startForeground(41, notification
            .setContentTitle("FRISS ASSIST aktif")
            .setContentText("Floating assistant sedang berjalan")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build())
    }

    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE

    private fun showBubble() {
        if (bubble != null) return
        val view = TextView(this).apply {
            text = "F"
            textSize = 21f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(blue)
                setStroke(dp(2), Color.WHITE)
            }
            alpha = opacity / 100f
            elevation = dp(8).toFloat()
            setOnClickListener { togglePanel() }
            setOnTouchListener(DragTouchListener())
        }
        val params = WindowManager.LayoutParams(dp(58), dp(58), overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(18); y = dp(180)
        }
        bubble = view
        bubbleParams = params
        windowManager.addView(view, params)
    }

    private fun togglePanel() {
        if (panel != null) {
            removePanel()
            return
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = GradientDrawable().apply {
                setColor(0xF7FFFFFF.toInt())
                cornerRadius = dp(20).toFloat()
                setStroke(dp(1), 0xFFD8E7FA.toInt())
            }
            elevation = dp(12).toFloat()
        }
        box.addView(TextView(this).apply {
            text = "FRISS ASSIST"
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(blue)
        })
        box.addView(TextView(this).apply {
            text = "Quick control"
            textSize = 12f
            setTextColor(0xFF64748B.toInt())
            setPadding(0, 0, 0, dp(8))
        })

        addLabel(box, "Opacity logo: $opacity%")
        val opacitySeek = SeekBar(this).apply {
            max = 100
            progress = opacity
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    opacity = progress.coerceAtLeast(15)
                    bubble?.alpha = opacity / 100f
                    (box.getChildAt(2) as TextView).text = "Opacity logo: $opacity%"
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        box.addView(opacitySeek)

        addLabel(box, "Kecerahan layar")
        val current = try { Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS) } catch (_: Exception) { 128 }
        val brightnessSeek = SeekBar(this).apply {
            max = 255
            progress = current
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (!fromUser) return
                    if (Settings.System.canWrite(this@FloatingAssistantService)) {
                        try { Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, progress.coerceAtLeast(1)) }
                        catch (_: Exception) { Toast.makeText(this@FloatingAssistantService, "Gagal mengubah kecerahan.", Toast.LENGTH_SHORT).show() }
                    } else {
                        Toast.makeText(this@FloatingAssistantService, "Izinkan akses ubah kecerahan dari aplikasi.", Toast.LENGTH_SHORT).show()
                    }
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        box.addView(brightnessSeek)
        addAction(box, "Google Lens", true) { openLens(this) }
        addAction(box, "Sembunyikan panel", false) { removePanel() }
        addAction(box, "Matikan asisten", false) { stopSelf() }

        val params = WindowManager.LayoutParams(dp(270), WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(), WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            val bp = bubbleParams
            x = (bp?.x ?: dp(18)).coerceAtMost(resources.displayMetrics.widthPixels - dp(280))
            y = (bp?.y ?: dp(180)) + dp(66)
        }
        panel = box
        panelParams = params
        try { windowManager.addView(box, params) } catch (_: Exception) { panel = null }
    }

    private fun addLabel(parent: LinearLayout, label: String) {
        parent.addView(TextView(this).apply {
            text = label
            textSize = 13f
            setTextColor(dark)
            setPadding(0, dp(8), 0, 0)
        })
    }

    private fun addAction(parent: LinearLayout, label: String, primary: Boolean, action: () -> Unit) {
        val button = Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 13f
            setTextColor(if (primary) Color.WHITE else dark)
            backgroundTintList = android.content.res.ColorStateList.valueOf(if (primary) blue else 0xFFEAF2FF.toInt())
            setOnClickListener { action() }
        }
        parent.addView(button, LinearLayout.LayoutParams(-1, dp(44)).apply { topMargin = dp(5) })
    }

    private fun removePanel() {
        panel?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        panel = null
        panelParams = null
    }

    private inner class DragTouchListener : View.OnTouchListener {
        private var startX = 0
        private var startY = 0
        private var touchX = 0f
        private var touchY = 0f
        private var moved = false
        override fun onTouch(view: View, event: MotionEvent): Boolean {
            val params = bubbleParams ?: return false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x; startY = params.y
                    touchX = event.rawX; touchY = event.rawY
                    moved = false
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchX).toInt()
                    val dy = (event.rawY - touchY).toInt()
                    if (kotlin.math.abs(dx) + kotlin.math.abs(dy) > dp(5)) moved = true
                    params.x = startX + dx
                    params.y = startY + dy
                    try { windowManager.updateViewLayout(view, params) } catch (_: Exception) {}
                    return true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) view.performClick()
                    return true
                }
            }
            return false
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        removePanel()
        bubble?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        bubble = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        fun openLens(context: Context) {
            val lensIntent = Intent("com.google.android.googlequicksearchbox.Lens").apply {
                setPackage("com.google.android.googlequicksearchbox")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            try {
                context.startActivity(lensIntent)
            } catch (_: Exception) {
                val googleIntent = context.packageManager.getLaunchIntentForPackage("com.google.android.googlequicksearchbox")
                if (googleIntent != null) {
                    googleIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(googleIntent)
                    Toast.makeText(context, "Google terbuka. Pilih ikon Lens jika tersedia.", Toast.LENGTH_LONG).show()
                } else {
                    try {
                        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://lens.google.com/")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    } catch (_: Exception) {
                        Toast.makeText(context, "Google Lens tidak ditemukan.", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }
}
