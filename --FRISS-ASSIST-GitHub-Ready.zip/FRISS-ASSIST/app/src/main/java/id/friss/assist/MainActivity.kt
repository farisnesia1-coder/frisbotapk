package id.friss.assist

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val blue = 0xFF1677FF.toInt()
    private val ink = 0xFF14243A.toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    override fun onResume() {
        super.onResume()
        if (::rootView.isInitialized) render()
    }

    private lateinit var rootView: LinearLayout

    private fun render() {
        rootView = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24.dp(), 30.dp(), 24.dp(), 24.dp())
            setBackgroundColor(0xFFF5F9FF.toInt())
        }

        val title = TextView(this).apply {
            text = "FRISS ASSIST"
            textSize = 27f
            setTextColor(blue)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        rootView.addView(title)
        rootView.addView(TextView(this).apply {
            text = "Floating tools, right where you need them."
            textSize = 14f
            setTextColor(0xFF64748B.toInt())
            setPadding(0, 4.dp(), 0, 22.dp())
        })

        addStatus("Izin overlay", Settings.canDrawOverlays(this))
        addStatus("Izin ubah kecerahan", Settings.System.canWrite(this))

        addButton("Izinkan tampil di atas aplikasi lain") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        addButton("Izinkan kontrol kecerahan") {
            startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))
        }
        addButton("Aktifkan FRISS ASSIST") {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Izinkan overlay dulu.", Toast.LENGTH_SHORT).show()
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else {
                val serviceIntent = Intent(this, FloatingAssistantService::class.java)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(serviceIntent)
                else startService(serviceIntent)
                Toast.makeText(this, "FRISS ASSIST aktif.", Toast.LENGTH_SHORT).show()
            }
        }
        addButton("Matikan floating assistant") {
            stopService(Intent(this, FloatingAssistantService::class.java))
            Toast.makeText(this, "FRISS ASSIST dimatikan.", Toast.LENGTH_SHORT).show()
        }
        addButton("Buka Google Lens") { FloatingAssistantService.openLens(this) }

        rootView.addView(TextView(this).apply {
            text = "Catatan: fitur overlay dan kontrol kecerahan memerlukan izin Android. Google Lens akan dibuka jika tersedia di perangkat."
            textSize = 12f
            setTextColor(0xFF64748B.toInt())
            setPadding(0, 22.dp(), 0, 0)
        })
        setContentView(rootView)
    }

    private fun addStatus(label: String, granted: Boolean) {
        rootView.addView(TextView(this).apply {
            text = "$label  •  ${if (granted) "Diizinkan" else "Belum diizinkan"}"
            textSize = 14f
            setTextColor(if (granted) 0xFF138A54.toInt() else 0xFFB45309.toInt())
            setPadding(0, 5.dp(), 0, 5.dp())
        })
    }

    private fun addButton(label: String, action: () -> Unit) {
        val button = Button(this).apply {
            text = label
            isAllCaps = false
            setTextColor(android.graphics.Color.WHITE)
            backgroundTintList = android.content.res.ColorStateList.valueOf(blue)
            setOnClickListener { action() }
        }
        rootView.addView(button, LinearLayout.LayoutParams(-1, 52.dp()).apply { topMargin = 9.dp() })
    }

    private fun Int.dp(): Int = (this * resources.displayMetrics.density).toInt()
}
