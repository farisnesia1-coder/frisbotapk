package id.friss.assist

import android.app.Activity
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.net.URLEncoder

class LensSelectionActivity : Activity() {
    private var screenshot: Bitmap? = null
    private lateinit var selector: ScreenAreaSelector
    private lateinit var content: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        screenshot = LensCaptureStore.screenshot
        if (screenshot == null) {
            Toast.makeText(this, "Screenshot tidak tersedia. Coba Lens lagi.", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        buildSelectionUi()
    }

    private fun buildSelectionUi() {
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFFF5F9FF.toInt())
        }
        content.addView(TextView(this).apply {
            text = "FRISS LENS · PILIH AREA"
            textSize = 18f
            setTextColor(0xFF1677FF.toInt())
            setPadding(18, 18, 18, 10)
            setTypeface(null, android.graphics.Typeface.BOLD)
        })
        content.addView(TextView(this).apply {
            text = "Geser kotak untuk memilih teks atau objek. Tarik handle kanan-bawah untuk mengubah ukuran."
            textSize = 13f
            setTextColor(0xFF53657C.toInt())
            setPadding(18, 0, 18, 12)
        })
        selector = ScreenAreaSelector(this, screenshot!!)
        content.addView(selector, LinearLayout.LayoutParams(-1, 0, 1f))

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(12, 8, 12, 12)
        }
        val cancel = Button(this).apply {
            text = "Batal"
            isAllCaps = false
            setOnClickListener { finish() }
        }
        val search = Button(this).apply {
            text = "Cari area"
            isAllCaps = false
            setTextColor(Color.WHITE)
            backgroundTintList = android.content.res.ColorStateList.valueOf(0xFF1677FF.toInt())
            setOnClickListener { recognizeSelection() }
        }
        actions.addView(cancel, LinearLayout.LayoutParams(0, -2, 1f))
        actions.addView(search, LinearLayout.LayoutParams(0, -2, 1f))
        content.addView(actions)
        setContentView(content)
    }

    private fun recognizeSelection() {
        val bitmap = screenshot ?: return
        val rect = selector.getCropRect(bitmap.width, bitmap.height)
        if (rect.width() < 12 || rect.height() < 12) {
            Toast.makeText(this, "Perbesar kotak seleksi terlebih dahulu.", Toast.LENGTH_SHORT).show()
            return
        }
        val crop = Bitmap.createBitmap(bitmap, rect.left, rect.top, rect.width(), rect.height())
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        Toast.makeText(this, "Membaca area yang dipilih...", Toast.LENGTH_SHORT).show()

        recognizer.process(InputImage.fromBitmap(crop, 0))
            .addOnSuccessListener { result ->
                crop.recycle()
                recognizer.close()
                val detectedText = result.text.trim()
                if (detectedText.isBlank()) {
                    Toast.makeText(this, "Belum ada teks terbaca. Coba area yang lebih jelas.", Toast.LENGTH_LONG).show()
                } else {
                    showInternalResults(detectedText)
                }
            }
            .addOnFailureListener {
                crop.recycle()
                recognizer.close()
                Toast.makeText(this, "OCR gagal. Coba pilih area lain.", Toast.LENGTH_LONG).show()
            }
    }

    private fun showInternalResults(query: String) {
        content.removeAllViews()
        content.addView(TextView(this).apply {
            text = "FRISS LENS · HASIL"
            textSize = 18f
            setTextColor(0xFF1677FF.toInt())
            setPadding(18, 18, 18, 8)
            setTypeface(null, android.graphics.Typeface.BOLD)
        })
        content.addView(TextView(this).apply {
            text = "Teks terdeteksi"
            textSize = 12f
            setTextColor(0xFF64748B.toInt())
            setPadding(18, 4, 18, 2)
        })
        content.addView(TextView(this).apply {
            text = query
            textSize = 14f
            setTextColor(0xFF172B45.toInt())
            setPadding(18, 4, 18, 10)
        })

        val web = WebView(this).apply {
            webViewClient = WebViewClient()
            settings.javaScriptEnabled = false
            loadUrl("https://www.google.com/search?q=" + URLEncoder.encode(query, "UTF-8"))
        }
        content.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))

        val footer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(12, 8, 12, 12)
        }
        footer.addView(Button(this).apply {
            text = "Pilih area lagi"
            isAllCaps = false
            setOnClickListener { buildSelectionUi() }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        footer.addView(Button(this).apply {
            text = "Tutup"
            isAllCaps = false
            setOnClickListener { finish() }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        content.addView(footer)
        setContentView(content)
    }

    override fun onDestroy() {
        screenshot?.recycle()
        screenshot = null
        LensCaptureStore.screenshot = null
        super.onDestroy()
    }

    private class ScreenAreaSelector(
        context: android.content.Context,
        private val bitmap: Bitmap
    ) : View(context) {
        private val bitmapPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        private val shadePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x77000000 }
        private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFF1677FF.toInt()
            style = Paint.Style.STROKE
            strokeWidth = 5f
        }
        private val handlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
        private val selection = RectF()
        private val imageBounds = RectF()
        private var lastX = 0f
        private var lastY = 0f
        private var resizing = false
        private val handleRadius = 24f

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val scale = minOf(width.toFloat() / bitmap.width, height.toFloat() / bitmap.height)
            val drawWidth = bitmap.width * scale
            val drawHeight = bitmap.height * scale
            val left = (width - drawWidth) / 2f
            val top = (height - drawHeight) / 2f
            imageBounds.set(left, top, left + drawWidth, top + drawHeight)
            canvas.drawBitmap(bitmap, null, imageBounds, bitmapPaint)

            if (selection.isEmpty) {
                selection.set(
                    imageBounds.left + drawWidth * .15f,
                    imageBounds.top + drawHeight * .25f,
                    imageBounds.left + drawWidth * .85f,
                    imageBounds.top + drawHeight * .55f
                )
            }
            canvas.save()
            canvas.clipRect(imageBounds)
            canvas.drawRect(imageBounds, shadePaint)
            val clipSave = canvas.save()
            canvas.clipRect(selection)
            canvas.drawBitmap(bitmap, null, imageBounds, bitmapPaint)
            canvas.restoreToCount(clipSave)
            canvas.drawRect(selection, borderPaint)
            canvas.drawCircle(selection.left, selection.top, handleRadius, handlePaint)
            canvas.drawCircle(selection.right, selection.top, handleRadius, handlePaint)
            canvas.drawCircle(selection.left, selection.bottom, handleRadius, handlePaint)
            canvas.drawCircle(selection.right, selection.bottom, handleRadius, handlePaint)
            canvas.restore()
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    lastX = event.x
                    lastY = event.y
                    resizing = kotlin.math.abs(event.x - selection.right) < handleRadius * 1.7f &&
                        kotlin.math.abs(event.y - selection.bottom) < handleRadius * 1.7f
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.x - lastX
                    val dy = event.y - lastY
                    if (resizing) {
                        selection.right = (selection.right + dx).coerceIn(selection.left + 70f, imageBounds.right)
                        selection.bottom = (selection.bottom + dy).coerceIn(selection.top + 70f, imageBounds.bottom)
                    } else {
                        val w = selection.width()
                        val h = selection.height()
                        val newLeft = (selection.left + dx).coerceIn(imageBounds.left, imageBounds.right - w)
                        val newTop = (selection.top + dy).coerceIn(imageBounds.top, imageBounds.bottom - h)
                        selection.set(newLeft, newTop, newLeft + w, newTop + h)
                    }
                    lastX = event.x
                    lastY = event.y
                    invalidate()
                    return true
                }
                MotionEvent.ACTION_UP -> return true
            }
            return true
        }

        fun getCropRect(sourceWidth: Int, sourceHeight: Int): android.graphics.Rect {
            val sx = sourceWidth / imageBounds.width()
            val sy = sourceHeight / imageBounds.height()
            val left = ((selection.left - imageBounds.left) * sx).toInt().coerceIn(0, sourceWidth - 1)
            val top = ((selection.top - imageBounds.top) * sy).toInt().coerceIn(0, sourceHeight - 1)
            val right = ((selection.right - imageBounds.left) * sx).toInt().coerceIn(left + 1, sourceWidth)
            val bottom = ((selection.bottom - imageBounds.top) * sy).toInt().coerceIn(top + 1, sourceHeight)
            return android.graphics.Rect(left, top, right, bottom)
        }
    }
}
