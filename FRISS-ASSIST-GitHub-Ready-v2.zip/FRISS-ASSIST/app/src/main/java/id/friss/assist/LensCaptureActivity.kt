package id.friss.assist

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.TextView
import android.view.Gravity
import android.widget.Toast

class LensCaptureActivity : Activity() {
    private val captureRequest = 8201

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
            setBackgroundColor(0xFFF5F9FF.toInt())
        }
        layout.addView(TextView(this).apply {
            text = "FRISS LENS"
            textSize = 25f
            setTextColor(0xFF1677FF.toInt())
            gravity = Gravity.CENTER
            setTypeface(null, android.graphics.Typeface.BOLD)
        })
        layout.addView(TextView(this).apply {
            text = "Izinkan berbagi layar untuk memilih area yang ingin dibaca. Screenshot diproses di perangkat untuk OCR."
            textSize = 15f
            setTextColor(0xFF34445A.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 16, 0, 22)
        })
        setContentView(layout)
        @Suppress("DEPRECATION")
        startActivityForResult(manager.createScreenCaptureIntent(), captureRequest)
    }

    @Deprecated("Deprecated API retained for compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != captureRequest) return
        if (resultCode != RESULT_OK || data == null) {
            Toast.makeText(this, "Izin tangkap layar dibatalkan.", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        val serviceIntent = Intent(this, LensCaptureService::class.java).apply {
            putExtra(LensCaptureService.EXTRA_RESULT_CODE, resultCode)
            putExtra(LensCaptureService.EXTRA_RESULT_DATA, data)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(serviceIntent)
        else startService(serviceIntent)
        finish()
    }
}
