package id.friss.assist

import android.graphics.Bitmap

object LensCaptureStore {
    @Volatile var screenshot: Bitmap? = null
}
